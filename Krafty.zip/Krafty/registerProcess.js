document.getElementById("btnhomeLogIn").onclick = function () {
    location.href = "http://localhost:63342/Krafty/login.html?_ijt=jgddp5kaeinkiqaue9eoa3g8u&_ij_reload=RELOAD_ON_SAVE";
};
var UserPropertie = /** @class */ (function () {
    function UserPropertie() {
        var searchInput1 = document.getElementById('searchInput1');
        var searchInput2 = document.getElementById('searchInput2');
        var searchInput3 = document.getElementById('searchInput3');
        var searchInput4 = document.getElementById('searchInput4');
        this.nameOfCategorie = searchInput1 === null || searchInput1 === void 0 ? void 0 : searchInput1.value;
        this.priceRange = parseInt(searchInput2 === null || searchInput2 === void 0 ? void 0 : searchInput2.value);
        this.countryOfItem = searchInput3 === null || searchInput3 === void 0 ? void 0 : searchInput3.value;
        this.krafterGender = searchInput4 === null || searchInput4 === void 0 ? void 0 : searchInput4.value;
    }
    return UserPropertie;
}());
var User = /** @class */ (function () {
    function User(name, password) {
        this.name = name;
        this.password = password;
    }
    return User;
}());
var userPropertie = JSON.parse(localStorage.getItem('propertie') || '[]');
document.getElementById("search-container_sub").onclick = function (e) {
    e.preventDefault();
    userPropertie.push(new UserPropertie());
    localStorage.setItem('propertie', JSON.stringify(userPropertie));
};
var users = JSON.parse(localStorage.getItem('users') || '[]');
document.forms.namedItem('formRegistr').onsubmit = function (e) {
    e.preventDefault();
    var name = document.getElementById('usernameRegistr');
    var password = document.getElementById('passwordRegistr');
    var confirm_password = document.getElementById('confirm_password');
    console.log('Name:', name === null || name === void 0 ? void 0 : name.value);
    console.log('Password:', password === null || password === void 0 ? void 0 : password.value);
    console.log('Confirm Password:', confirm_password === null || confirm_password === void 0 ? void 0 : confirm_password.value);
    if (password && confirm_password && password.value === confirm_password.value) {
        users.push(new User(name === null || name === void 0 ? void 0 : name.value, password === null || password === void 0 ? void 0 : password.value));
        localStorage.setItem('users', JSON.stringify(users));
    }
};

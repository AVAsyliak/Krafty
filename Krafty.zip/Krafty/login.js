class User{
    name;
    password;

    constructor(name, password) {
        this.name = name;
        this.password = password;
    }
}
let users = JSON.parse(localStorage.getItem('users') || '[]');
document.forms.namedItem('loginform').addEventListener(function (e) {
    e.preventDefault();
    let name = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    for (const user of users) {
        if(name===user.name && password===user.password){
            location.href = "http://localhost:63342/Krafty/home_page.html?_ijt=7huu4m0ajhnj7pv17u2a1cktu9&_ij_reload=RELOAD_ON_SAVE";
        }else{
            alert('Incorrect password or name!')
        }
    }
});
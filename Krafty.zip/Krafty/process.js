class User{
    name;
    password;

    constructor(name, password) {
        this.name = name;
        this.password = password;
    }
}
let users = JSON.parse(localStorage.getItem('users') || '[]');

document.forms.namedItem('formRegistr').onsubmit = function (e) {
    e.preventDefault();
    let name = document.getElementById('usernameRegistr');
    let password = document.getElementById('passwordRegistr');
    let confirm_password = document.getElementById('confirm_password');
    if (password && confirm_password && password.value === confirm_password.value) {
        users.push(new User(name?.value, password?.value));
        localStorage.setItem('users', JSON.stringify(users));
    }
};
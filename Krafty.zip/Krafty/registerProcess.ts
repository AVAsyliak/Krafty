document.getElementById("btnhomeLogIn").onclick = function () {
    location.href = "http://localhost:63342/Krafty/login.html?_ijt=jgddp5kaeinkiqaue9eoa3g8u&_ij_reload=RELOAD_ON_SAVE";
};
class UserPropertie{
    nameOfCategorie:string;
    priceRange:number;
    countryOfItem:string;
    krafterGender:string;


    constructor() {
        let searchInput1 = document.getElementById('searchInput1') as HTMLInputElement;
        let searchInput2 = document.getElementById('searchInput2') as HTMLInputElement;
        let searchInput3 = document.getElementById('searchInput3') as HTMLInputElement;
        let searchInput4 = document.getElementById('searchInput4') as HTMLInputElement;
        this.nameOfCategorie = searchInput1?.value;
        this.priceRange = parseInt(searchInput2?.value);
        this.countryOfItem = searchInput3?.value;
        this.krafterGender = searchInput4?.value;
    }


}
class User{
    name:string;
    password:string;

    constructor(name: string, password: string) {
        this.name = name;
        this.password = password;
    }
}
let userPropertie = JSON.parse(localStorage.getItem('propertie') || '[]');
document.getElementById("search-container_sub").onclick = function (e) {
    e.preventDefault();
    userPropertie.push(new UserPropertie());
    localStorage.setItem('propertie', JSON.stringify(userPropertie))
};
let users: User[] = JSON.parse(localStorage.getItem('users') || '[]');

document.forms.namedItem('formRegistr').onsubmit = function (e: Event) {
    e.preventDefault();
    let name = document.getElementById('usernameRegistr') as HTMLInputElement;
    let password = document.getElementById('passwordRegistr') as HTMLInputElement;
    let confirm_password = document.getElementById('confirm_password') as HTMLInputElement;
    console.log('Name:', name?.value);
    console.log('Password:', password?.value);
    console.log('Confirm Password:', confirm_password?.value);
    if (password && confirm_password && password.value === confirm_password.value) {
        users.push(new User(name?.value, password?.value));
        localStorage.setItem('users', JSON.stringify(users));
    }
};


